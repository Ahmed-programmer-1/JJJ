# turbo.py - FAST PARALLEL MODE: many episodes at once inside ONE browser window / ONE page.
#
#  The page is a "grid" of small players (iframes, like a multi-player wall). Every cell loads one episode page, presses its server,
#  presses play inside the nested players and watches the network of ITS OWN frames only. As soon as a verified m3u8 shows up the cell
#  is emptied (the iframe is destroyed, freeing its CPU/RAM) and takes the next episode.  Verification and downloads run in threads.
#
#  RACE: for every episode the page's servers are pressed one after another just to HARVEST their embed (player) URLs - about a second
#  each, no waiting for video.  Each embed URL then gets its own cell (opened directly, like a multi-player wall) and all of them run at
#  the same time; the first verified m3u8 wins and the other cells of that episode are emptied at once.
#
#  Works on top of the existing engine: the caller passes the two modules it already has (`mg` = megamax_grab, `hc` = hunter_core;
#  in the single-file hunter.py both are that very module).  Single thread, Playwright sync API, nothing blocks for long:
#  each cell is a small state machine advanced a few times per second, so one stuck cell can never freeze the others.
import re
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urljoin, urlparse

GRID_PATH = "/__turbo_grid__"
NUDGE_AT = (2, 4, 6, 9, 12, 15, 19, 23, 27, 32)   # seconds after a server press: "play" nudges + a real click on the player
HARVEST_WAIT = 7           # seconds to wait for the embed after pressing one server while harvesting
HARVEST_TIMEOUT = 90       # hard limit for harvesting all servers of one episode
SERVER_TIMEOUT = 32        # seconds to wait for media after pressing one server (no host list)
HOST_TIMEOUT = 28          # seconds per Megamax host
LOAD_TIMEOUT = 30          # episode page must show servers / a player within this time
JOB_TIMEOUT = 260          # hard limit for one attempt of one episode (all servers together)
MAX_CELLS = 24
IDLE_AFTER = 9            # a player that made no request at all for this long (after the first nudges) will not deliver: free its cell early


def grid_html(n):
    return """<!doctype html><html><head><meta charset="utf-8"><title>Turbo grid</title><style>
body{margin:0;background:#0b0f14;color:#e8edf3;font:12px system-ui,Tahoma,sans-serif}
#top{padding:6px 10px;background:#10151c;position:sticky;top:0;z-index:2;direction:rtl}
#g{display:grid;grid-template-columns:repeat(auto-fill,300px);gap:6px;padding:6px;justify-content:center}
.c{width:300px;background:#1a212b;border-radius:6px;overflow:hidden}
.cap{padding:3px 6px;height:20px;line-height:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;direction:rtl}
.w{width:300px;height:170px;overflow:hidden;background:#000}
iframe{width:1280px;height:720px;border:0;transform:scale(.2344);transform-origin:0 0;display:block;background:#000}
.run .cap{background:#274a7a}.ok .cap{background:#1f5f35}.bad .cap{background:#6b2230}
</style></head><body><div id="top">Turbo</div><div id="g"></div><script>
const g=document.getElementById('g');
for(let i=0;i<%d;i++){const d=document.createElement('div');d.className='c';d.id='c'+i;d.innerHTML='<div class="cap">-</div><div class="w"></div>';g.appendChild(d)}
window.__set=(i,url,cap,cls)=>{const d=document.getElementById('c'+i),w=d.querySelector('.w');d.className='c '+(cls||'run');d.querySelector('.cap').textContent=cap;
  w.innerHTML='';if(url){const f=document.createElement('iframe');f.name='c'+i;f.allow='autoplay; fullscreen; encrypted-media';f.setAttribute('allowfullscreen','');f.src=url;w.appendChild(f)}};
window.__cap=(i,cap,cls)=>{const d=document.getElementById('c'+i);d.className='c '+(cls||'');d.querySelector('.cap').textContent=cap};
window.__top=t=>{document.getElementById('top').textContent=t};
</script></body></html>""" % n


def verify_task(mg, url, ref, body, min_sec):
    # runs in a worker thread: only plain HTTP here (never touches Playwright). -> {"kind", "secs"} or None
    low = url.lower()
    if any(k in low for k in mg.DECOY_MARKERS):
        return None
    kind, total = mg.probe(url, ref)
    if kind is None and body and body.lstrip().startswith("#EXTM3U"):
        kind = "hls"   # the browser itself received this playlist, even if scripts cannot
    if kind is None:
        return None
    if kind == "mp4" and not mg.ALLOW_MP4:
        return None
    secs = mg.mp4_seconds(url, ref, total) if kind == "mp4" else mg.hls_seconds(url, ref, body)
    if secs is None:   # unreadable by every method (plain / browser headers / Chrome fingerprint): the download would get 403 as well
        return None
    if secs < min_sec:
        return None
    return {"kind": kind, "secs": secs}


class Cell:
    def __init__(self, i):
        self.i, self.page = i, None
        self.clear()

    def clear(self):
        self.job = self.site = self.task = self.hv = None
        self.state = "idle"   # idle | loading | harvest | harvesting | serving | done | harvested | failed
        self.caught, self.pending, self.checked, self.retry = {}, {}, {}, {}
        self.t_job = self.t_state = self.t_host = 0.0
        self.urls, self.url_i = [], 0
        self.order, self.pos, self.items, self.cur = [], 0, [], None
        self.hl = None                 # Megamax host list: {"frame", "names", "i", "phase", "name"}
        self.mp4, self.mp4_deadline = None, None
        self.nudged = self.scans = 0
        self.last_scan = self.last_probe = self.last_hl = 0.0
        self.overlay = self.pressed = False
        self.rec = None


class Turbo:
    def __init__(self, mg, hc, ctx, page, cells=6, mode="iframe", log=print):
        self.mg, self.hc, self.ctx, self.page, self.log = mg, hc, ctx, page, log
        self.mode = mode
        self.n = max(1, min(MAX_CELLS, int(cells)))
        self.cells = [Cell(i) for i in range(self.n)]
        self.vpool = ThreadPoolExecutor(max_workers=max(4, self.n))
        self.fcache, self.pagemap = {}, {}
        self.main = None
        self.grid_url = self.html = ""
        self.saved = {}
        self.block_assets = True
        self.creating = False
        self.race = 0
        self.activity = {}   # cell index -> time of the last non-image request seen in it
        self.subq = []        # embed / server tasks waiting for a free cell (served before new episodes)

    # ------------------------------------------------------------ setup / teardown
    def start(self, origin_url):
        mg = self.mg
        o = urlparse(origin_url)
        self.grid_url = f"{o.scheme}://{o.netloc}{GRID_PATH}"
        self.html = grid_html(self.n)
        H = mg.HANDLERS
        self.saved = dict(H)
        try:
            self.ctx.unroute("**/*", H["route"])
        except Exception:
            pass
        for ev in ("request", "response", "page"):
            try:
                self.ctx.remove_listener(ev, H[ev])
            except Exception:
                pass
        self.ctx.route("**/*", self.on_route)
        self.ctx.on("request", self.on_request)
        self.ctx.on("response", self.on_response)
        self.ctx.on("page", self.on_page)
        if self.mode == "tab":
            self.creating = True      # on_page must not close the tabs we open ourselves
            try:
                for c in self.cells:
                    c.page = self.ctx.new_page()
                    c.page.on("dialog", lambda d: d.dismiss())
                    self.pagemap[c.page] = c.i
            finally:
                self.creating = False
            self.main = None
        else:
            rows = (self.n + 3) // 4
            try:
                self.page.set_viewport_size({"width": 1280, "height": min(2400, rows * 205 + 60)})
            except Exception:
                pass
            self.page.goto(self.grid_url, wait_until="domcontentloaded", timeout=30000)
            self.main = self.page.main_frame

    def stop(self):
        mg = self.mg
        self.vpool.shutdown(wait=False, cancel_futures=True)
        for ev, fn in (("request", self.on_request), ("response", self.on_response), ("page", self.on_page)):
            try:
                self.ctx.remove_listener(ev, fn)
            except Exception:
                pass
        try:
            self.ctx.unroute("**/*", self.on_route)
        except Exception:
            pass
        H = self.saved
        try:
            self.ctx.route("**/*", H["route"])
            self.ctx.on("request", H["request"])
            self.ctx.on("response", H["response"])
            self.ctx.on("page", H["page"])
        except Exception:
            pass
        for c in self.cells:
            if c.page is not None:
                try:
                    c.page.close()
                except Exception:
                    pass
        try:
            if self.mode == "iframe":
                self.page.goto("about:blank", timeout=10000)
                self.page.set_viewport_size({"width": 1280, "height": 720})
        except Exception:
            pass

    # ------------------------------------------------------------ browser hooks
    def on_page(self, pg):
        if self.creating or pg is self.page or pg in self.pagemap:
            return
        try:
            pg.close()    # ad popups
        except Exception:
            pass

    def on_route(self, r):
        mg = self.mg
        try:
            req = r.request
            url = req.url
            base = url.split("#")[0].split("?")[0]
            if base == self.grid_url:
                return r.fulfill(status=200, content_type="text/html; charset=utf-8", body=self.html)
            fr = req.frame
            top = fr.parent_frame is None
            nav = req.is_navigation_request()
            host = urlparse(url).netloc.lower()
            ad = any(k in host for k in mg.BLOCK_HOSTS)
            if nav and top and self.mode == "iframe" and not url.startswith(("about:", "data:", "blob:")):
                return r.abort()       # something tried to take over the grid page (ad hijack): stay here
            if nav and top and ad:
                return r.fulfill(status=204, body="")
            if ad and mg.BLOCK_ADS:
                return r.abort()
            if self.block_assets and req.resource_type in ("image", "font"):
                return r.abort()
            if nav and not top and self.mode == "iframe" and fr.parent_frame is self.main:
                # the episode page itself, shown inside our frame: drop the headers that forbid framing
                resp = r.fetch()
                hdr = {k: v for k, v in resp.headers.items() if k.lower() != "x-frame-options"}
                for k in list(hdr):
                    if k.lower() == "content-security-policy":
                        v = re.sub(r"frame-ancestors[^;]*;?", "", hdr[k], flags=re.I).strip()
                        if v:
                            hdr[k] = v
                        else:
                            del hdr[k]
                return r.fulfill(response=resp, headers=hdr)
        except Exception:
            pass
        try:
            r.continue_()
        except Exception:
            pass

    def idx_of(self, fr):
        # which cell does a frame (or any nested frame) belong to?
        try:
            if self.mode == "tab":
                return self.pagemap.get(fr.page)
            if fr in self.fcache:
                return self.fcache[fr]
            top = fr
            while top.parent_frame is not None and top.parent_frame is not self.main:
                top = top.parent_frame
            if top.parent_frame is None:
                return None
            name = top.name or ""
            if not re.fullmatch(r"c\d+", name):
                try:
                    name = top.frame_element().get_attribute("name") or ""
                except Exception:
                    name = ""
            m = re.fullmatch(r"c(\d+)", name)
            if not m:
                return None
            self.fcache[fr] = int(m.group(1))
            return self.fcache[fr]
        except Exception:
            return None

    def on_request(self, rq):
        mg = self.mg
        try:
            if rq.resource_type not in ("image", "font", "stylesheet"):
                j = self.idx_of(rq.frame)
                if j is not None:
                    self.activity[j] = time.time()
            if mg.is_media(rq.url) or rq.resource_type in ("xhr", "fetch", "media"):
                host = urlparse(rq.url).netloc
                if (mg.is_media(rq.url) or host not in mg.BROWSER_HDRS) and not any(k in host for k in mg.BLOCK_HOSTS):
                    try:
                        mg.keep_browser_headers(rq.url, rq.all_headers())   # exactly what the browser sends to this CDN
                    except Exception:
                        mg.keep_browser_headers(rq.url, rq.headers)
            if not mg.is_media(rq.url):
                return
            i = self.idx_of(rq.frame)
            if i is not None and i < len(self.cells):
                self.cells[i].caught.setdefault(rq.url, {"referer": rq.headers.get("referer") or rq.frame.url, "frame": rq.frame.url})
        except Exception:
            pass

    def on_response(self, resp):
        mg = self.mg
        try:
            rq = resp.request
            ct = (resp.headers.get("content-type") or "").lower()
            if rq.resource_type in ("image", "font", "stylesheet") or ct.startswith(("image/", "font/", "audio/mp2t", "video/mp2t")):
                return
            i = self.idx_of(rq.frame)
            if i is None or i >= len(self.cells):
                return
            c, ref, fu = self.cells[i], rq.frame.url, rq.frame.url
            if ct.startswith(("video/mp4", "video/webm", "video/x-matroska")) or rq.resource_type == "media":
                c.caught.setdefault(resp.url, {"referer": ref, "frame": fu})
                return
            if int(resp.headers.get("content-length") or 0) > 600_000:
                return
            if ct and not any(k in ct for k in ("text", "json", "javascript", "octet", "xml", "mpegurl", "x-")):
                return
            body = resp.text()
            if body.lstrip().startswith("#EXTM3U"):
                c.caught.setdefault(resp.url, {"referer": ref, "frame": fu})["body"] = body[:300000]
                return
            for u in mg.find_media(body, resp.url):
                if mg.is_media(u):
                    c.caught.setdefault(u, {"referer": ref, "frame": fu})
        except Exception:
            pass

    # ------------------------------------------------------------ frames of a cell
    def group_frames(self):
        groups, tops = {}, {}
        if self.mode == "tab":
            for c in self.cells:
                if c.page is not None and not c.page.is_closed():
                    groups[c.i] = list(c.page.frames)
                    tops[c.i] = c.page.main_frame
            return groups, tops
        for fr in list(self.page.frames):
            i = self.idx_of(fr)
            if i is None:
                continue
            groups.setdefault(i, []).append(fr)
            if fr.parent_frame is self.main:
                tops[i] = fr
        return groups, tops

    def is_player(self, fr):
        u = fr.url or ""
        return u.startswith("http") and not any(k in u for k in self.mg.BLOCK_HOSTS)

    @staticmethod
    def depth(fr):
        d = 0
        while fr.parent_frame is not None:
            fr, d = fr.parent_frame, d + 1
        return d

    def mouse_page(self, c):
        return c.page if self.mode == "tab" else self.page

    def player_frame(self, c, frames):
        best, key = None, (-1, 0)
        for fr in frames:
            if not self.is_player(fr):
                continue
            try:
                if fr.parent_frame is None:
                    area = 1
                else:
                    box = fr.frame_element().bounding_box()
                    area = (box["width"] * box["height"]) if box else 0
            except Exception:
                continue
            k = (self.depth(fr), area)
            if area and k > key:
                best, key = fr, k
        return best

    # ------------------------------------------------------------ cell control
    def caption(self, c, text, cls="run"):
        if self.mode == "iframe":
            try:
                self.page.evaluate("([i,t,k]) => window.__cap && __cap(i,t,k)", [c.i, text, cls])
            except Exception:
                pass

    def load(self, c, url):
        c.caught.clear()
        c.checked.clear()
        c.pending.clear()
        c.retry.clear()
        label = c.job["label"] if c.job else ""
        if self.mode == "tab":
            try:
                c.page.goto(url, wait_until="commit", timeout=25000, referer=self.mg.DEFAULT_REFERER)
            except Exception as e:
                self.log(f"   [{label}] load warning: {str(e).splitlines()[0]}")
        else:
            self.page.evaluate("([i,u,t,k]) => __set(i,u,t,k)", [c.i, url, label, "run"])

    def release(self, c, text="", cls=""):
        # empty the cell: the iframe is destroyed, so its player stops and its memory is freed
        try:
            if self.mode == "tab":
                c.page.goto("about:blank", timeout=8000)
            else:
                self.page.evaluate("([i,t,k]) => __set(i,'',t,k)", [c.i, text, cls])
        except Exception:
            pass
        for f in list(c.pending.values()):
            f.cancel()
        c.clear()

    def assign(self, c, task):
        c.clear()
        job = task["job"]
        c.task, c.job, c.site = task, job, self.hc.site_for(job["ep"]["href"])
        c.urls = c.site.watch_urls(job["ep"]) if c.site else [job["ep"]["href"]]
        c.url_i = 0
        now = c.t_job = c.t_state = time.time()
        kind = task["kind"]
        if kind == "embed":          # a server's player opened directly in its own cell
            c.state, c.cur = "serving", task["name"]
            c.last_hl = c.last_scan = now
            self.log(f"   [{job['label']}] player: {task['name']}")
            self.caption(c, f"{job['label']} · {task['name']}")
            return self.load(c, task["url"])
        c.state = "harvest" if kind == "harvest" else "loading"
        self.log(f"\n[{job['label']}] {job['ep']['title']}" + ("" if kind in ("legacy", "harvest") else f"  (server {task['name']})"))
        self.load(c, c.urls[0])

    # ------------------------------------------------------------ the state machine
    def step(self, c, tops, groups, now):
        if c.state in ("loading", "harvest"):
            self.step_loading(c, tops.get(c.i), groups.get(c.i, []), now)
        elif c.state == "harvesting":
            self.step_harvest(c, tops.get(c.i), groups.get(c.i, []), now)
        elif c.state == "serving":
            self.step_serving(c, tops.get(c.i), groups.get(c.i, []), now)

    def fail_job(self, c, why):
        self.log(f"   [{c.job['label']}] {why}")
        c.state = "failed"

    def step_loading(self, c, top, frames, now):
        mg, hc = self.mg, self.hc
        dt = now - c.t_state
        if top is None:
            if dt > 15:
                return self.next_url_or_fail(c, "the page did not open")
            return
        if (top.url or "").startswith("chrome-error"):
            return self.next_url_or_fail(c, "the page refused to load inside a frame (try tab mode: turbo mode = tab)")
        if now - c.last_probe < 1.2:
            return
        c.last_probe = now
        try:
            items = (c.site.pre_servers(top) if c.site else None) or hc.generic_servers(top)
        except Exception:
            items = []
        if items:
            names = [n for _, n in items]
            c.items = items
            if not c.order:
                scope = f"outer:{c.site.key}"
                c.order = [n for n in mg.rank_names(scope, names, tuple(c.prefer), c.avoid) if n not in c.job["bad"]]
                gone = [n for n in dict.fromkeys(names) if n not in c.order and n not in c.job["bad"]]
                if gone:
                    self.log(f"   [{c.job['label']}] avoiding: {', '.join(gone)}")
                if c.task["kind"] == "server":      # one named server (it could not be harvested): only that one
                    c.order = [c.task["name"]] if c.task["name"] in names else []
                self.log(f"   [{c.job['label']}] servers: {mg.explain(f'outer:{c.site.key}', c.order) or '(none)'}")
            if c.task["kind"] == "harvest":
                return self.begin_harvest(c, now)
            return self.next_server(c, now)
        if dt > 6 and not c.overlay:
            c.overlay = True
            try:
                hc.press_overlay(top)
            except Exception:
                pass
        if dt > 9 and not c.order:
            try:
                own = hc.own_player(top) or any(hc.is_embed(hc.norm_url(x)) for x in (hc.safe_eval(top, hc.JS_IFRAMES, []) or []))
            except Exception:
                own = False
            if own:
                c.order, c.items = ["page"], []
                if c.task["kind"] == "harvest":     # no server list: the page's own player, worked on in the page itself
                    self.spawn(c.job, "page", None, "server")
                    c.state = "harvested"
                    return
                return self.next_server(c, now)
        if dt > LOAD_TIMEOUT:
            self.next_url_or_fail(c, "no servers found on the watch page")

    # ------------------------------------------------------------ harvesting embed URLs
    def spawn(self, job, name, url, kind):
        self.subq.append({"job": job, "kind": kind, "name": name, "url": url})

    def begin_harvest(self, c, now):
        c.state, c.hv = "harvesting", {"i": 0, "phase": "click", "t": now, "before": set(), "seen": set()}
        c.t_job = now
        self.log(f"   [{c.job['label']}] harvesting players of: {', '.join(c.order)}")

    def step_harvest(self, c, top, frames, now):
        hc, hv, job = self.hc, c.hv, c.job
        if now - c.t_job > HARVEST_TIMEOUT:
            c.state = "harvested"
            return
        if top is None:
            return
        if hv["i"] >= len(c.order):
            c.state = "harvested"
            return
        name = c.order[hv["i"]]
        if hv["phase"] == "click":
            loc = next((l for l, n in c.items if n == name), None)
            hv["before"] = {f.url for f in frames}
            if loc is None or not self.click(loc):
                self.spawn(job, name, None, "server")      # cannot press it here: the normal way will try it
                hv["i"] += 1
                return
            hv["phase"], hv["t"] = "wait", now
            return
        inner = [f for f in frames if f is not top and self.is_player(f) and f.url not in hv["seen"]]
        fresh = [f for f in inner if f.url not in hv["before"]]
        emb = (fresh or [])[:1] or ([inner[0]] if inner and now - hv["t"] >= 3 else [])   # a player the page loaded by itself counts too
        if not emb and now - hv["t"] < HARVEST_WAIT:
            return
        hv["i"], hv["phase"] = hv["i"] + 1, "click"
        if not emb:
            self.spawn(job, name, None, "server")
            return
        url = emb[0].url
        hv["seen"].add(url)
        if hc.is_wrapper(url, job["ep"]["href"]):
            self.spawn(job, name, None, "server")           # the platform's own player only works inside its page
            self.log(f"   [{job['label']}] {name}: player lives inside the page (will run there)")
        else:
            self.spawn(job, name, url, "embed")
            self.log(f"   [{job['label']}] {name}: {url[:110]}")

    def next_url_or_fail(self, c, why):
        if c.url_i + 1 < len(c.urls):
            c.url_i += 1
            c.t_state, c.last_probe, c.overlay = time.time(), 0.0, False
            return self.load(c, c.urls[c.url_i])
        self.fail_job(c, why)

    def next_server(self, c, now):
        mg = self.mg
        while c.pos < len(c.order):
            name = c.order[c.pos]
            c.pos += 1
            loc = next((l for l, n in c.items if n == name), None)
            if name != "page" and loc is None:
                continue
            if loc is not None and not self.click(loc):
                mg.record(f"outer:{c.site.key}", name, False)
                continue
            c.cur, c.state, c.t_state = name, "serving", now
            c.hl, c.nudged, c.pressed = None, 0, False
            c.last_hl, c.last_scan = now, now
            c.caught.clear()
            c.checked.clear()
            c.retry.clear()
            c.mp4 = c.mp4_deadline = None
            self.log(f"   [{c.job['label']}] server: {name}")
            self.caption(c, f"{c.job['label']} · {name}")
            return
        self.fail_job(c, "no m3u8 from any server")

    @staticmethod
    def click(loc):
        try:
            loc.click(timeout=4000)
            return True
        except Exception:
            pass
        try:
            loc.click(force=True, timeout=2500)
            return True
        except Exception:
            pass
        try:
            loc.dispatch_event("click")
            return True
        except Exception:
            return False

    def server_failed(self, c, why, now):
        mg = self.mg
        self.log(f"   [{c.job['label']}] {c.cur}: {why}, next server")
        mg.record(f"outer:{c.site.key}", c.cur, False)
        if c.task and c.task["kind"] == "embed":
            return self.fail_job(c, "this player gave nothing")
        if c.pos >= len(c.order):
            return self.fail_job(c, "no m3u8 from any server")
        c.state, c.t_state, c.last_probe, c.overlay = "loading", now, 0.0, False
        self.load(c, c.urls[c.url_i])     # clean page for the next server

    def step_serving(self, c, top, frames, now):
        mg = self.mg
        dt = now - c.t_state
        if top is None and self.mode == "iframe":
            if dt > 6:
                return self.server_failed(c, "the frame disappeared", now)
            return
        self.collect(c, frames, now)
        self.poll_verify(c, now)
        if c.state != "serving":
            return
        # nudges: play + a real click on the deepest player
        while c.nudged < len(NUDGE_AT) and dt >= NUDGE_AT[c.nudged]:
            c.nudged += 1
            for fr in frames:
                if self.is_player(fr):
                    try:
                        fr.evaluate(mg.JS_NUDGE)
                    except Exception:
                        pass
            pf = self.player_frame(c, frames)
            if pf is not None:
                mg.click_center(self.mouse_page(c), pf)
        # Megamax-style host list inside a nested frame
        if c.hl is None and now - c.last_hl >= 1.5:
            c.last_hl = now
            own = c.task is not None and c.task["kind"] == "embed"      # an embed opened on its own: its host list is in its top frame
            inner = [f for f in frames if (f is not top or own) and self.is_player(f)]
            if not inner and self.mode == "tab":
                inner = [f for f in frames if f is not top]
            for fr in inner:
                try:
                    if len(fr.evaluate(mg.JS_ROWS, mg.HOST_RX)) >= 2:
                        c.hl = {"frame": fr, "names": None, "i": 0, "phase": "pick", "name": None}
                        break
                except Exception:
                    continue
            if c.hl is None and dt > 5 and not c.pressed and inner:
                c.pressed = True      # the window may show a poster with one big play button before its host list
                try:
                    mg.press_play(self.page, inner)
                except Exception:
                    pass
        if c.hl is not None:
            return self.step_hosts(c, now)
        idle = now - max(self.activity.get(c.i, 0), c.t_state)
        if not c.pending and (dt > SERVER_TIMEOUT or (dt > 14 and idle > IDLE_AFTER)):
            self.server_failed(c, "no usable m3u8 here" if dt > SERVER_TIMEOUT else "the player is idle", now)

    def hl_rows(self, fr):
        mg = self.mg
        try:
            return fr.evaluate(mg.JS_ROWS, mg.HOST_RX)
        except Exception:
            return []

    def step_hosts(self, c, now):
        mg, h = self.mg, c.hl
        fr = h["frame"]
        try:
            if fr.is_detached():
                return self.server_failed(c, "the host window closed", now)
        except Exception:
            pass
        if h["phase"] == "pick":
            rows = self.hl_rows(fr)
            if h["names"] is None:
                all_names = [r["name"] for r in rows]
                names = [n for n in dict.fromkeys(all_names) if n not in c.job["tried"] and not mg.avoided(n)]
                h["names"] = mg.rank_names("megamax", names)
                self.log(f"   [{c.job['label']}] hosts: {mg.explain('megamax', h['names']) or '(none left)'}")
            if h["i"] >= len(h["names"]):
                return self.server_failed(c, "every host failed", now)
            name = h["names"][h["i"]]
            row = next((r for r in rows if r["name"] == name), None)
            if row is None:
                if now - c.t_host > 8 or c.t_host == 0:
                    c.t_host = c.t_host or now
                    if now - c.t_host > 8:
                        h["i"] += 1
                        c.t_host = 0.0
                return
            c.caught.clear()
            c.checked.clear()
            c.retry.clear()
            c.mp4 = c.mp4_deadline = None
            if not mg.click_row(fr, row["idx"]):
                h["i"] += 1
                return
            h["name"], h["phase"], c.t_host = name, "wait", now
            self.log(f"   [{c.job['label']}] trying {name} ...")
            self.caption(c, f"{c.job['label']} · {c.cur}/{name}")
            return
        # phase "wait": candidates are handled by collect()/poll_verify(); here only the host timeout
        idle = now - max(self.activity.get(c.i, 0), c.t_host)
        if not c.pending and (now - c.t_host > HOST_TIMEOUT or (now - c.t_host > 12 and idle > IDLE_AFTER)):
            mg.record("megamax", h["name"], False)
            c.job["tried"].add(h["name"])
            self.log(f"   [{c.job['label']}] {h['name']}: nothing usable, next host")
            self.go_back(fr)
            h["i"] += 1
            h["phase"], c.t_host = "pick", 0.0

    def go_back(self, fr):
        for pat in (r"^\s*(?:←\s*)?back\s*$", r"رجوع"):
            try:
                loc = fr.get_by_text(re.compile(pat, re.I)).first
                if loc.count():
                    loc.click(timeout=2000)
                    return True
            except Exception:
                continue
        return False

    # ------------------------------------------------------------ media candidates
    def collect(self, c, frames, now):
        mg = self.mg
        if now - c.last_scan >= 4:
            c.last_scan, c.scans = now, c.scans + 1
            for fr in frames:
                if not self.is_player(fr):
                    continue
                try:
                    for u in fr.evaluate(mg.JS_SCAN):
                        u = urljoin(fr.url, mg.clean(u)) if not u.startswith("http") else mg.clean(u)
                        if mg.is_media(u):
                            c.caught.setdefault(u, {"referer": fr.url, "frame": fr.url})
                    if c.scans % 3 == 0:
                        for u in mg.find_media(fr.content(), fr.url):
                            if mg.is_media(u):
                                c.caught.setdefault(u, {"referer": fr.url, "frame": fr.url})
                except Exception:
                    continue
        min_sec = c.job.get("min_seconds") or self.min_seconds
        for url in sorted(c.caught, key=mg.rank):
            if len(c.pending) >= 3:
                break
            if url in c.pending or c.checked.get(url, 0) >= 2 or c.retry.get(url, 0) > now:
                continue
            info = c.caught[url]
            ref = info.get("referer") or mg.DEFAULT_REFERER
            try:
                mg.COOKIES[urlparse(url).netloc] = "; ".join(f"{k['name']}={k['value']}" for k in self.ctx.cookies(url))
            except Exception:
                pass
            c.pending[url] = self.vpool.submit(verify_task, mg, url, ref, info.get("body"), min_sec)

    def poll_verify(self, c, now):
        mg = self.mg
        for url, fut in list(c.pending.items()):
            if not fut.done():
                continue
            del c.pending[url]
            try:
                res = fut.result()
            except Exception:
                res = None
            if not res:
                c.checked[url] = c.checked.get(url, 0) + 1
                c.retry[url] = now + 4
                continue
            ref = c.caught[url].get("referer") or mg.DEFAULT_REFERER
            if res["kind"] == "hls":
                return self.found(c, url, ref, res, now)
            if c.mp4 is None:      # an m3u8 may still show up; otherwise the MP4 is used
                c.mp4, c.mp4_deadline = (url, ref, res), now + 6
        if c.mp4 and now >= c.mp4_deadline and c.state == "serving":
            url, ref, res = c.mp4
            self.found(c, url, ref, res, now)

    def found(self, c, url, ref, res, now):
        mg = self.mg
        host = (c.hl or {}).get("name") or (c.cur or "").lower()
        mg.KINDS[url], mg.DURATIONS[url] = res["kind"], res["secs"]
        if c.hl:
            mg.record("megamax", host, True, "cap")
        mg.record(f"outer:{c.site.key}", c.cur, True, "cap")
        c.rec = {"host": host, "url": url, "referer": ref, "kind": res["kind"], "server": c.cur,
                 "embed": c.caught[url].get("frame") or ref}
        self.log(f"   [{c.job['label']}] OK ({res['secs'] / 60:.1f} min, {res['kind']}) via {c.cur}/{host}")
        c.state = "done"


def run_jobs(mg, hc, ctx, page, jobs, slug, pool, prefer=("megamax",), avoid=None, cancel=lambda: False, on_result=None, dl=None,
             cells=6, mode="iframe", race=3, log=print):
    # Same contract as hunter_core.run_jobs, but `cells` episodes are worked on at the same time.
    # Returns the jobs that could not be completed.
    out_path, dl, lost = f"{slug}_m3u8.txt", dl or mg.dl_task, []
    if not jobs:
        return []
    T = Turbo(mg, hc, ctx, page, cells, mode, log)
    T.min_seconds = mg.MIN_SECONDS
    T.race = max(0, int(race))
    T.prefer = tuple(prefer)
    T.avoid = list(avoid) if avoid is not None else list(mg.AVOID)
    try:
        T.start(jobs[0]["ep"]["href"])
    except Exception as e:
        T.stop()
        raise RuntimeError(f"turbo grid could not start: {str(e).splitlines()[0]}")
    for c in T.cells:
        c.prefer, c.avoid = T.prefer, T.avoid
    log(f"Turbo: {T.n} players at once ({'one page, small frames' if mode == 'iframe' else 'tabs'})")

    def ok(j, rec):
        mg.write_lines(out_path, j["label"], [rec])
        if on_result:
            on_result(j, rec)

    try:
        for rnd in range(1, mg.MAX_ROUNDS + 2):
            if not jobs or cancel():
                break
            if rnd > 1:
                log(f"\n=== Retry round {rnd}: {len(jobs)} item(s), other servers first ===")
            for j in jobs:
                j.pop("_won", None)
                j.pop("_dead", None)
            queue = [{"job": j, "kind": "harvest" if T.race else "legacy", "name": "", "url": None} for j in jobs]
            T.subq = []
            failed, futs, total, done_n = [], [], len(jobs), 0
            LIVE = ("loading", "harvest", "harvesting", "serving")

            def settle(block=False):
                for item in list(futs):
                    j, rec, fut = item
                    if not (fut.done() or block):
                        continue
                    futs.remove(item)
                    if fut.result():
                        ok(j, rec)
                    else:
                        site = hc.site_for(j["ep"]["href"])
                        if hc.is_megamax(rec["server"], rec["embed"]):
                            j["tried"].add(rec["host"])
                        else:
                            j["bad"].add(rec["server"])
                        failed.append(j)

            def job_fail(j):
                if j.get("_dead") or j.get("_won"):
                    return
                j["_dead"] = True
                j["nolink"] += 1
                if j["nolink"] < 2:
                    log(f"   [{j['label']}] no m3u8 from any server (will retry once more with other servers)")
                else:
                    log(f"   [{j['label']}] no m3u8 from any server")
                (failed if j["nolink"] < 2 else lost).append(j)

            def job_alive(j):
                return (any(c.job is j and c.state in LIVE for c in T.cells) or any(t["job"] is j for t in T.subq)
                        or any(t["job"] is j for t in queue))

            def running(j):
                return sum(1 for c in T.cells if c.job is j and c.state in ("loading", "serving"))

            while True:
                if cancel():
                    break
                for c in T.cells:
                    if c.state != "idle":
                        continue
                    task = None
                    for k, t in enumerate(T.subq):
                        if running(t["job"]) < max(1, T.race):
                            task = T.subq.pop(k)
                            break
                    if task is None and queue:
                        task = queue.pop(0)
                    if task is not None:
                        c.prefer, c.avoid = T.prefer, T.avoid
                        T.min_seconds = mg.MIN_SECONDS
                        T.assign(c, task)
                if all(c.state == "idle" for c in T.cells) and not queue and not T.subq:
                    break
                now = time.time()
                groups, tops = T.group_frames()
                for c in T.cells:
                    if c.state in LIVE:
                        try:
                            if c.state != "harvesting" and now - c.t_job > JOB_TIMEOUT:
                                T.fail_job(c, "timed out")
                            else:
                                T.step(c, tops, groups, now)
                        except Exception as e:
                            log(f"   [{c.job['label']}] error: {str(e).splitlines()[0] if str(e) else repr(e)}")
                            if c.state == "serving":
                                try:
                                    T.server_failed(c, "error", now)
                                except Exception:
                                    T.fail_job(c, "error")
                            else:
                                T.fail_job(c, "error")
                    if c.state == "done":
                        j, rec = c.job, c.rec
                        if not j.get("_won"):
                            j["_won"] = True
                            T.subq = [t for t in T.subq if t["job"] is not j]
                            for c2 in T.cells:          # the race is over: empty this episode's other cells
                                if c2 is not c and c2.job is j and c2.state in LIVE:
                                    T.release(c2)
                            mg.write_lines(f"{slug}_embed.txt", j["label"], [{"host": rec["server"], "url": rec["embed"]}])
                            if pool:
                                futs.append((j, rec, pool.submit(dl, j, rec)))
                            else:
                                ok(j, rec)
                                log(f"   [{j['label']}] saved: {rec['url']}")
                            done_n += 1
                        T.release(c, j["label"] + " ✓", "ok")
                    elif c.state in ("failed", "harvested"):
                        j, legacy = c.job, c.task["kind"] == "legacy"
                        T.release(c, j["label"] + (" ✗" if c.state == "failed" else ""), "bad" if c.state == "failed" else "")
                        if legacy or not job_alive(j):
                            job_fail(j)
                settle()
                try:
                    if mode == "iframe":
                        T.page.evaluate("t => window.__top && __top(t)", f"Turbo · {done_n}/{total} · {len(queue)} waiting")
                except Exception:
                    pass
                page.wait_for_timeout(300)
            if cancel():
                for c in T.cells:
                    if c.job:
                        T.release(c)
            settle(block=True)
            jobs = failed
    finally:
        T.stop()
    return jobs + lost
